<?php 
Route::get('timezones/{timezone}', 
  'djpack\djadmin\DjnewController@index');